<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Jumperlane | Arga Pratanda</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?php echo base_url();?>asset/css/bootstrap.min.css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		
		<div class="container">
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<nav class="navbar navbar-default" role="navigation">
				<div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#">Travel Bloggers</a>
					</div>
			
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse navbar-ex1-collapse">
						<ul class="nav navbar-nav">
							<li class="active"><a href="<?php echo site_url()?>/home">Home</a></li>
							<li><a href="<?php echo site_url()?>/about">About</a></li>
							<li><a href="<?php echo site_url()?>/contact">Contact</a></li>
						</ul>
						<ul class="nav navbar-nav navbar-right">
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">Administrator<b class="caret"></b></a>
								<ul class="dropdown-menu">
									<li><a href="#">Edit</a></li>
									<li><a href="#">Logout</a></li>
								</ul>
							</li>
						</ul>
					</div><!-- /.navbar-collapse -->
				</div>
			</nav>
			<div class="jumbotron">
				<img src="<?php echo base_url();?>asset/5.jpg" class="img-responsive" alt="Image">
				<div class="container">
					<h1>Welcome Traveller</h1>
					<p>Oh Well , Whatever Nevermind</p>
					<p>
						<a class="btn btn-primary btn-lg">Learn more</a>
					</p>
				</div>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
			<h1>Travel Bloggers By Matt Long</h1>
				I don’t normally pontificate on LandLopers about travel blogs and social media, well not much at least. I usually save those not-so weighty thoughts for other sites and discussion groups. But this is a question I myself have been tossing about in my noggin and I think it’s a discussion that benefits all readers of blogs, because it speaks to the core of why they visit.

Blogs are strange imps of the online world. The term was coined in the late 1990s, but several individuals started websites with daily, personal updates a few years prior. 1999 was a banner year for the blogger, the term was coined and people around the world started experimenting with this new way of sharing their thoughts with the world, all in reverse-chronological order of course.

As technology made it easier for bloggers to emerge, a cascade of writing began to fill the inter-webs until we had the large, diverse population of bloggers we see today. Many blogs are only marginally considered blogs, by definition. The look of many sites, including my own, is decidedly unbloglike and while personal thoughts and impressions are imbued in every post, these sites ofttimes take on more of an informational role. Either way though, blogs are a form of social media as they encourage and depend on readers to interact in an online community of enthusiasts

The travel world was slow to enter this universe, for a variety of reasons. The industry itself wasn’t in any hurry to encourage independent, non/quasi/sorta writers/journalists/thinkers and the individuals themselves lacked the technology to actively travel and maintain a site. There are exceptions of course, and many of the early travel bloggers still write and are in fact leaders in the industry. Industry. I bet that’s a term no one would have thought to apply to blogs in 1999.

And yet that’s where we find ourselves now. I’m not sure who’s to thank/blame for the emergence of the blogdustry, Facebook had a major role to play, as did simple word of mouth, the best way for any blog to grow. Facebook was an important instigator because of their insistence to create a world where everything a person wants to know, from which deodorant is best to where to vacation, is available online in a social platform. Facebook isn’t completely there yet, but in its attempts it has created an environment where it’s not only ok to accept such advice from friends, associates and influencers, it’s almost become the norm.

People are skeptical by nature, it’s just how we function. Corporate websites and ads are great, but ultimately there is an undercurrent of mistrust. As consumers we wonder if they are lying, always suspicious of anything they say. Corporations and other large entities work in their own best interest, that’s kind of how the free market works. But as a consumer, who knows what they say is real or not? Yeah, the hotel looks amazing on the web site, but what will it really be like when we arrive?

<img src="<?php echo base_url();?>asset/1.jpg" class="img-responsive" alt="Image">
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				This gets me to the real question of what is a travel blog. Through sites like TripAdvisor, the traveling public, I think, got used to the idea of accepting advice and recommendations from strangers. The entries look honest (whether or not they’re accurate is a subject for another time) and ideally they had nothing to gain with their reviews. Finally, there was an honest forum through which to make travel decisions without corporate or feel good PR rose colored glasses.

Travel blogs fill this same niche of wanting to hear from real people about the travel experience. People taking a year long break to travel the world began writing, travel agents began to write, travel writers began to write, random people who like to travel began to write until, finally, we have the robust travel blogosphere we enjoy today. Technology has helped, without question. It takes very minimal effort to at least start and maintain a travel blog. But to what end?

For many round the world, year long sabbatical travelers, it’s a way to keep friends and family updated back home. If others read it, that’s great, but after the trip finishes, the site usually does as well. (There are exceptions to every rule, including this one) Still others have a passion for the travel experience, be it from a professional background or not, and just want to share their thoughts and experiences to help others as they plan their own journeys.

At its core, this is what a good travel blog should be. Anyone can pick up a copy of Lonely Planet or Frommers, find the top museums, attractions, hotels and restaurants and go off on vacation reasonably well prepared. Why then do people read travel blogs at all? Because they want more.

Take Gary Arndt of Everything-Everywhere travel blog for example. His site generates more traffic than many mainstream travel sites and magazines. They have staffs, advertising, age and that all important veritas. What does Gary have? Well he’s smart, well traveled and likes to share his experiences. People flock to him more than the mainstream sites because he’s a real, breathing person. People can’t identify with entities or companies, but they can identify with other people. That’s the appeal, Gary is like them and because of that, his readers feel like they can achieve the same travel feats he has.

There is a natural tendency to want to classify and categorize things; that too is human nature. So many times I hear the question, are travel bloggers: writers, journalists, photographers, marketers, PR pros, techies, etc? The answer is we are none of these, but we are all of these. Travel blogs aren’t going to replace travel guides, the excellent writing in travel magazines or Sunday supplements, marketing campaigns or world class public relations; travel blogs are a separate entity and instead augment all of these institutions. We’re meant to inspire, to provoke and yes, to help in the actual act of traveling itself. We all stray from this sometimes, for one reason or another, but overall the travel blog is about people helping people, and that’s why I love writing my blog.

Industry is warming up to travel blogs as well. Destinations and companies are beginning to catch on to the return on investment of having real people talk about their cities, countries, products, etc. A great example is the Lanai New-Media-Artist-in-Residence program led by PR pioneer Roxanne Darling. You can read about the full program, which I was part of, in her post, but some important statistics are important to point out. After the effort, which was six months in length and involved seven bloggers, she was able to quantify the following:

516% increase on Twitter for Visit Lanai
2.5 million new Google results for Lanai
Visitor spending up 28%
715% return on investment based on production costs
That’s real value folks. I would love to say that seven bloggers are responsible for all of this, but in truth it was done in conjunction with good marketing and good PR. Everything worked together in a cohesive manner.

It would be too easy to say that we live in an age of cynicism and distrust and shy away from anything institutional. The truth is that humans have always lived in such an age. What’s different now is that we have the tools to respond to this cynicism in unique ways. In the travel world, travel blogs are the ombudsman to an industry that needs it. We offer a true voice, a real voice, an honest voice. Travel magazines and newspaper articles will always exist and they will always have fantastic content. Travel marketing and advertising with amazing tropical beaches and palm trees will always exist and they serve to inspire. But bloggers bring it all together in one package. Are we perfect, do we all write well, do we all have helpful and useful information? No, of course not. But over time the community will refine itself and grow stronger as each site stakes its claim and serves its audience.

What do I intend to do? I intend to do as I have done for almost two years, to travel as I can and share those experiences with you all. Hopefully you find inspiration and useful information, but more importantly, I hope you have fun reading the site. Now that’s a travel blog.
			</div>
		</div>
			
		</div>

		<!-- jQuery -->
		<script src="//code.jquery.com/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="<?php echo base_url()?>asset/js/bootstrap.min.js"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
 		<script src="Hello World"></script>
	</body>
</html>